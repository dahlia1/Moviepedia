package com.amarydev.moviedia.core.data.response

import com.google.gson.annotations.SerializedName
import java.util.*

class DisMovieResponse (
    @SerializedName("results") val results: ArrayList<ResultMovieResponse>
)