package com.amarydev.moviedia.core.domain.repository

import androidx.lifecycle.LiveData
import com.amarydev.moviedia.core.data.network.ApiResponse
import com.amarydev.moviedia.core.domain.model.DetailMovie
import com.amarydev.moviedia.core.domain.model.ResultMovie

interface IMovieRepository {
    fun getAllMovies() : LiveData<ApiResponse<List<ResultMovie>>>
    fun getDetailMovie(movie_id: Int) : LiveData<ApiResponse<DetailMovie>>
}