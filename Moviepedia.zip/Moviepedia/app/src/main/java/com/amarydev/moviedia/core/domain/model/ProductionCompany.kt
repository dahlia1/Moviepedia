package com.amarydev.moviedia.core.domain.model

data class ProductionCompany (
    val name: String
    )