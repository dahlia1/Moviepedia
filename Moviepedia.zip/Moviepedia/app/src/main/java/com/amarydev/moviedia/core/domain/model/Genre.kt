package com.amarydev.moviedia.core.domain.model

data class Genre(
   val name: String
)
