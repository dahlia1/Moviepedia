package com.amarydev.moviepediaa.core.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.amarydev.moviedia.core.data.MovieDataSource
import com.amarydev.moviedia.core.data.network.ApiResponse
import com.amarydev.moviedia.core.data.response.mapToDomain
import com.amarydev.moviedia.core.domain.model.DetailMovie
import com.amarydev.moviedia.core.domain.model.ResultMovie
import com.amarydev.moviedia.core.domain.repository.IMovieRepository

class MovieRepository private constructor(
    private val movieDataSource: MovieDataSource
) : IMovieRepository {

    companion object {
        @Volatile
        private var instance: MovieRepository? = null

        fun getInstance(
            movieDataSource: MovieDataSource
        ): MovieRepository =
            instance ?: synchronized(this) {
                instance ?: MovieRepository(movieDataSource)
            }
    }

    override fun getAllMovies(): LiveData<ApiResponse<List<ResultMovie>>> {
        return Transformations.map(movieDataSource.getAllMovie()){response->
            when (response) {
                is ApiResponse.Success -> ApiResponse.Success(response.data.mapToDomain())
                is ApiResponse.Empty -> ApiResponse.Empty
                is ApiResponse.Error -> ApiResponse.Error(response.errorMessage)
            }
        }
    }

    override fun getDetailMovie(movie_id: Int): LiveData<ApiResponse<DetailMovie>> {
        return Transformations.map(movieDataSource.getDetailMovie(movie_id)){response->
            when (response) {
                is ApiResponse.Success -> ApiResponse.Success(response.data.mapToDomain())
                is ApiResponse.Empty -> ApiResponse.Empty
                is ApiResponse.Error -> ApiResponse.Error(response.errorMessage)
            }
        }
    }
}