package com.amarydev.moviedia.utils

import android.annotation.SuppressLint
import java.text.SimpleDateFormat
import java.util.*

object DateConvert {
    @SuppressLint("SimpleDateFormat")
    fun convert(date: String?): String? {
        var date = date
        try {
            var simpleDateFormat = SimpleDateFormat("yyyy-MM-dd")
            val convertDate = simpleDateFormat.parse(date)
            simpleDateFormat = SimpleDateFormat("MMMM dd, yyyy",Locale.ENGLISH)
            date = simpleDateFormat.format(convertDate)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return date
    }

    @SuppressLint("SimpleDateFormat")
    fun convertMonth(date: String?): String? {
        var date = date
        try {
            var simpleDateFormat = SimpleDateFormat("yyyy-MM-dd")
            val convertDate = simpleDateFormat.parse(date)
            simpleDateFormat = SimpleDateFormat("MM")
            date = simpleDateFormat.format(convertDate)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return date
    }
}