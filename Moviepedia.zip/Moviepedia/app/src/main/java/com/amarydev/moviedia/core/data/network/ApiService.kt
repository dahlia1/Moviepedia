package com.amarydev.moviedia.core.data.network

import com.amarydev.moviedia.core.data.network.ApiConfig.API_KEY
import com.amarydev.moviedia.core.data.response.DetailMovieResponse
import com.amarydev.moviedia.core.data.response.DisMovieResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("movie/now_playing")
    fun getMovieRelease(
        @Query("api_key") api_key: String? = API_KEY,
        @Query("language") language: String? = "en-US"
    ): Call<DisMovieResponse>

    @GET("movie/{movie_id}")
    fun getDetailMovie(
        @Path("movie_id") movie_id: Int,
        @Query("api_key") api_key: String? =API_KEY,
        @Query("language") language: String? = "en-US"
    ): Call<DetailMovieResponse>
}
