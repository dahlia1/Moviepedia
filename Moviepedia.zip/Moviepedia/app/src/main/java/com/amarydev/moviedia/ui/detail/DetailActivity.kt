package com.amarydev.moviedia.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import com.amarydev.moviedia.R
import com.amarydev.moviedia.core.data.network.ApiConfig
import com.amarydev.moviedia.core.data.network.ApiResponse
import com.amarydev.moviedia.core.domain.model.DetailMovie
import com.amarydev.moviedia.core.domain.model.ResultMovie
import com.amarydev.moviedia.utils.DateConvert
import com.amarydev.moviedia.utils.ViewModelFactory
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.item_movie.*
import kotlinx.android.synthetic.main.item_movie.view.*
import java.lang.StringBuilder
import java.util.*

class DetailActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_MOVIE = "id_movie"
    }

    private lateinit var detailViewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = "Movies"

        val resultMovie = intent.getParcelableExtra<ResultMovie>(EXTRA_MOVIE)
        txt_info_title_movie.text = resultMovie?.title

        val factory = ViewModelFactory.getInstance(this)
        detailViewModel = ViewModelProvider(this, factory)[DetailViewModel::class.java]
        isLoading(true)

        resultMovie?.let { detailViewModel.getDetailMovie(it.id).observe(this, {response->
            when (response) {
                is ApiResponse.Success -> {
                    isLoading(false)
                    isErrorData(false)
                    dataDetail(response.data)
                }
                is ApiResponse.Empty -> {
                    isLoading(true)
                    isErrorData(true)
                }
                is ApiResponse.Error -> {
                    isLoading(false)
                    isErrorData(true)
                }
            }
            })
        }
    }

    private fun dataDetail(detailMovie: DetailMovie) {
        val gnrMovie = arrayOfNulls<String>(detailMovie.genres.size)
        val pdrMovie = arrayOfNulls<String>(detailMovie.productionCompanies.size)
        txt_info_tanggal_movie.text = DateConvert.convert(detailMovie.releaseDate)
        txt_info_score_movie.text = detailMovie.voteAverage.toString()

        for (i in detailMovie.genres.indices) {
            gnrMovie[i] = detailMovie.genres[i].name
            printArray(
                gnrMovie,
                txt_info_genre_movie
            )
        }
        for (m in detailMovie.productionCompanies.indices) {
            pdrMovie[m] = detailMovie.productionCompanies[m].name
            printArray(
                pdrMovie,
                txt_info_production_movie
            )
        }

        txt_info_homepage_movie.text =detailMovie.homepage
        txt_info_overview_movie.text = detailMovie.overview

        Glide.with(this)
            .load(ApiConfig.COVER_IMAGE + "w342" + "/"+ detailMovie.posterPath)
            .into(img_info_poster_movie)

        Glide.with(this)
            .load(ApiConfig.COVER_IMAGE + "w342" + "/"+ detailMovie.backdropPath)
            .into(img_info_backdroppath_movie)
    }

    private fun printArray(anArray: Array<String?>, textView: TextView) {
        val sb = StringBuilder()
        for (i in anArray.indices) {
            if (i > 0) {
                sb.append(", ")
            }
            sb.append(anArray[i])
        }
        textView.text = sb.toString()
    }

    private fun isLoading(loading: Boolean){
        if (loading){
            progressBar_movie.visibility = View.VISIBLE
            tv_genre.visibility = View.GONE
            tv_production.visibility = View.GONE
            tv_homepage.visibility = View.GONE
            tv_sinopsis.visibility = View.GONE
        } else {
            progressBar_movie.visibility = View.GONE
            tv_genre.visibility = View.VISIBLE
            tv_production.visibility = View.VISIBLE
            tv_homepage.visibility = View.VISIBLE
            tv_sinopsis.visibility = View.VISIBLE
        }
    }

    private fun isErrorData(error: Boolean) {
        if (error){
            progressBar_movie.visibility = View.GONE
            tv_detail_error_movie.visibility = View.VISIBLE
            tv_genre.visibility = View.GONE
            tv_production.visibility = View.GONE
            tv_homepage.visibility = View.GONE
            tv_sinopsis.visibility = View.GONE
            tv_description.visibility = View.GONE
            txt_info_tanggal_movie.visibility = View.GONE
            txt_info_genre_movie.visibility = View.GONE
            txt_info_score_movie.visibility = View.GONE
            txt_info_production_movie.visibility = View.GONE
            txt_info_homepage_movie.visibility = View.GONE
            txt_info_overview_movie.visibility = View.GONE
            img_info_poster_movie.visibility = View.GONE
            img_info_backdroppath_movie.visibility = View.GONE
            v_1.visibility = View.GONE
            v_2.visibility = View.GONE
            v_3.visibility = View.GONE
        } else{
            progressBar_movie.visibility = View.GONE
            tv_detail_error_movie.visibility = View.GONE
            tv_genre.visibility = View.VISIBLE
            tv_production.visibility = View.VISIBLE
            tv_homepage.visibility = View.VISIBLE
            tv_sinopsis.visibility = View.VISIBLE
            tv_description.visibility = View.VISIBLE
            txt_info_tanggal_movie.visibility = View.VISIBLE
            txt_info_genre_movie.visibility = View.VISIBLE
            txt_info_score_movie.visibility = View.VISIBLE
            txt_info_production_movie.visibility = View.VISIBLE
            txt_info_homepage_movie.visibility = View.VISIBLE
            txt_info_overview_movie.visibility = View.VISIBLE
            img_info_poster_movie.visibility = View.VISIBLE
            img_info_backdroppath_movie.visibility = View.VISIBLE
            v_1.visibility = View.VISIBLE
            v_2.visibility = View.VISIBLE
            v_3.visibility = View.VISIBLE
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}