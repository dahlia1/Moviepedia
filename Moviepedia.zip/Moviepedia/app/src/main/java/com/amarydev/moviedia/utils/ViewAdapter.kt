package com.amarydev.moviedia.utils

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.amarydev.moviedia.R
import com.amarydev.moviedia.core.data.network.ApiConfig.COVER_IMAGE
import com.amarydev.moviedia.core.domain.model.ResultMovie
import com.amarydev.moviedia.ui.detail.DetailActivity
import com.amarydev.moviedia.ui.detail.DetailActivity.Companion.EXTRA_MOVIE
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item_movie.view.*
import java.util.*

class ViewAdapter : RecyclerView.Adapter<ViewAdapter.ViewHolder>() {

    private var listData = ArrayList<ResultMovie>()

    @SuppressLint("NotifyDataSetChanged")
    fun setData(newListData: List<ResultMovie>?) {
        if (newListData == null) return
        listData.clear()
        listData.addAll(newListData)
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_movie, parent, false))


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = listData[position]
        holder.bind(data)
    }

    override fun getItemCount() = listData.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(data: ResultMovie) {
            itemView.txt_judul.text = data.title
            itemView.txt_tgl_rilis.text = DateConvert.convert(data.releaseDate)
            itemView.txt_rating.text = data.voteAverage.toString()

            Glide.with(itemView)
                .load(COVER_IMAGE + "w342"+ "/"+ data.posterPath)
                .into(itemView.img_poster)

            Glide.with(itemView)
                .load(COVER_IMAGE + "w342" + "/"+ data.backdropPath)
                .into(itemView.img_backdrops)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra(EXTRA_MOVIE, data)
                itemView.context.startActivity(intent)
            }
        }

    }
}