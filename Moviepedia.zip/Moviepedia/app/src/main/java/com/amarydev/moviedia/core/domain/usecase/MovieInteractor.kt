package com.amarydev.moviedia.core.domain.usecase

import com.amarydev.moviedia.core.domain.repository.IMovieRepository

class MovieInteractor (private val iMovieRepository: IMovieRepository): MovieUseCase {
    override fun getAllMovies() = iMovieRepository.getAllMovies()
    override fun getDetailMovie(movie_id: Int) = iMovieRepository.getDetailMovie(movie_id)
}