package com.amarydev.moviedia.core.domain.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResultMovie (
    val id: Int,
    val voteAverage: Double,
    val title: String,
    val posterPath: String,
    val backdropPath: String,
    val releaseDate: String
) : Parcelable