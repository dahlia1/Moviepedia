package com.amarydev.moviedia.ui.detail

import androidx.lifecycle.ViewModel
import com.amarydev.moviedia.core.domain.usecase.MovieUseCase

class DetailViewModel(private val movieUseCase: MovieUseCase) : ViewModel() {
    fun getDetailMovie(movie_id: Int) = movieUseCase.getDetailMovie(movie_id)
}