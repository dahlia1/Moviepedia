package com.amarydev.moviedia.core.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.amarydev.moviedia.core.data.network.ApiResponse
import com.amarydev.moviedia.core.data.network.ApiService
import com.amarydev.moviedia.core.data.response.DetailMovieResponse
import com.amarydev.moviedia.core.data.response.DisMovieResponse
import com.amarydev.moviedia.core.data.response.ResultMovieResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MovieDataSource private constructor(private val apiService: ApiService){
    companion object {
        @Volatile
        private var instance: MovieDataSource? = null

        fun getInstance(service: ApiService): MovieDataSource =
            instance ?: synchronized(this) {
                instance
                    ?: MovieDataSource(service)
            }
    }

    fun getAllMovie() : LiveData<ApiResponse<List<ResultMovieResponse>>>{
        val resultData = MutableLiveData<ApiResponse<List<ResultMovieResponse>>>()

        val client = apiService.getMovieRelease()
        client.enqueue(object : Callback<DisMovieResponse>{
            override fun onResponse(
                call: Call<DisMovieResponse>,
                response: Response<DisMovieResponse>
            ) {
                val dataArray = response.body()?.results
                resultData.value = if (dataArray != null) ApiResponse.Success(dataArray) else ApiResponse.Empty
            }

            override fun onFailure(call: Call<DisMovieResponse>, t: Throwable) {
                resultData.value = ApiResponse.Error(t.message.toString())
            }

        })

        return resultData
    }

    fun getDetailMovie(movie_id: Int): LiveData<ApiResponse<DetailMovieResponse>>{
        val resultData = MutableLiveData<ApiResponse<DetailMovieResponse>>()
        val client = apiService.getDetailMovie(movie_id)

        client.enqueue(object : Callback<DetailMovieResponse>{
            override fun onResponse(
                call: Call<DetailMovieResponse>,
                response: Response<DetailMovieResponse>
            ) {
                val data = response.body()
                resultData.value = if (data != null) ApiResponse.Success(data) else ApiResponse.Empty
            }

            override fun onFailure(call: Call<DetailMovieResponse>, t: Throwable) {
                resultData.value = ApiResponse.Error(t.message.toString())
            }

        })


        return resultData
    }
}