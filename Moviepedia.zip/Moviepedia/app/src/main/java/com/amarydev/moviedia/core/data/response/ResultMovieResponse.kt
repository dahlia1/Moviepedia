package com.amarydev.moviedia.core.data.response

import com.amarydev.moviedia.core.domain.model.ResultMovie
import com.google.gson.annotations.SerializedName

data class ResultMovieResponse (
    @SerializedName("id") val id: Int,
    @SerializedName("vote_average") val voteAverage: Double,
    @SerializedName("title") val title: String,
    @SerializedName("poster_path") val posterPath: String,
    @SerializedName("backdrop_path") val backdropPath: String,
    @SerializedName("release_date") val releaseDate: String
)

fun ResultMovieResponse.mapToDomain() : ResultMovie = ResultMovie(
    id,voteAverage,title,posterPath,backdropPath,releaseDate
)

fun List<ResultMovieResponse>.mapToDomain() : List<ResultMovie> = map { it.mapToDomain() }