package com.amarydev.moviedia.core.data.response

import com.amarydev.moviedia.core.domain.model.DetailMovie
import com.google.gson.annotations.SerializedName

data class DetailMovieResponse (
    @SerializedName("backdrop_path") var backdropPath: String,
    @SerializedName("genres") var genres: List<GenreResponse>,
    @SerializedName("homepage") var homepage: String,
    @SerializedName("overview") var overview: String,
    @SerializedName("poster_path") var posterPath: String,
    @SerializedName("production_companies") var productionCompanies: List<ProductionCompanyResponse>,
    @SerializedName("release_date") var releaseDate: String,
    @SerializedName("vote_average") var voteAverage: Double
)

fun DetailMovieResponse.mapToDomain() : DetailMovie = DetailMovie(
    backdropPath, genres.mapToDomain(),homepage, overview, posterPath, productionCompanies.mapToDomain(), releaseDate, voteAverage
)