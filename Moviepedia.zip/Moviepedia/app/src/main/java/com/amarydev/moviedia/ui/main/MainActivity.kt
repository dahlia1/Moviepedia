package com.amarydev.moviedia.ui.main

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.amarydev.moviedia.R
import com.amarydev.moviedia.core.data.network.ApiResponse
import com.amarydev.moviedia.utils.ViewAdapter
import com.amarydev.moviedia.utils.ViewModelFactory
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val viewAdapter = ViewAdapter()

        val factory = ViewModelFactory.getInstance(this)
        mainViewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        mainViewModel.movies.observe(this, {response ->
            when (response) {
                is ApiResponse.Success -> {
                    pb_loading.visibility = View.GONE
                    tv_error_get.visibility = View.GONE
                    rv_movies.visibility = View.VISIBLE

                    viewAdapter.setData(response.data)
                }
                is ApiResponse.Empty -> {
                    pb_loading.visibility = View.VISIBLE
                    tv_error_get.visibility = View.GONE
                    rv_movies.visibility = View.GONE
                }
                is ApiResponse.Error -> {
                    pb_loading.visibility = View.GONE
                    tv_error_get.visibility = View.VISIBLE
                    rv_movies.visibility = View.GONE
                }
            }
        })

        with(rv_movies){
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = viewAdapter
        }
    }
}