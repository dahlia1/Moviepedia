package com.amarydev.moviedia.core.domain.model

data class DetailMovie (
    var backdropPath: String,
    var genres: List<Genre>,
    var homepage: String,
    var overview: String,
    var posterPath: String,
    var productionCompanies: List<ProductionCompany>,
    var releaseDate: String,
    var voteAverage: Double
)