package com.amarydev.moviedia.ui.main

import androidx.lifecycle.ViewModel
import com.amarydev.moviedia.core.domain.usecase.MovieUseCase

class MainViewModel (movieUseCase: MovieUseCase) : ViewModel() {
    val movies = movieUseCase.getAllMovies()
}