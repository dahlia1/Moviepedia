package com.amarydev.moviedia.core.data.response

import com.amarydev.moviedia.core.domain.model.Genre
import com.google.gson.annotations.SerializedName

data class GenreResponse(
    @SerializedName("name") val name: String
)

fun GenreResponse.mapToDomain() : Genre = Genre(name)


fun List<GenreResponse>.mapToDomain() : List<Genre> = map { it.mapToDomain() }
