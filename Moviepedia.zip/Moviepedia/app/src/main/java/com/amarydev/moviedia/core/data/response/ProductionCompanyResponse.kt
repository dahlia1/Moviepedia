package com.amarydev.moviedia.core.data.response

import com.amarydev.moviedia.core.domain.model.ProductionCompany
import com.google.gson.annotations.SerializedName

data class ProductionCompanyResponse (
    @SerializedName("name")
    val name: String
    )


fun ProductionCompanyResponse.mapToDomain() : ProductionCompany = ProductionCompany(name)


fun List<ProductionCompanyResponse>.mapToDomain() : List<ProductionCompany> = map { it.mapToDomain() }